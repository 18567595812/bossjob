package com.example.bossjobassistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class BossAccessibilityService : AccessibilityService() {
    private var lastNotice=0L
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "com.hpbr.bosszhipin") return
        val root=rootInActiveWindow ?: return
        val text=read(root).lowercase()
        val signals=listOf("职位","招聘","薪资","经验","学历","岗位")
        if (signals.count{text.contains(it)} < 2) return
        val p=getSharedPreferences("config",0)
        val keys=(p.getString("keywords","")? : "").split(",")
        val bad=(p.getString("exclude","")? : "").split(",")
        val matched=keys.any{it.trim().isNotEmpty() && text.contains(it.trim().lowercase())}
        val blocked=bad.any{it.trim().isNotEmpty() && text.contains(it.trim().lowercase())}
        if(matched && !blocked && System.currentTimeMillis()-lastNotice>5000){
            lastNotice=System.currentTimeMillis()
            Toast.makeText(this,"发现符合条件岗位，请检查后手动投递",Toast.LENGTH_SHORT).show()
        }
    }
    private fun read(n:AccessibilityNodeInfo):String{
        val s=StringBuilder(); n.text?.let{s.append(it).append(' ')}; n.contentDescription?.let{s.append(it).append(' ')}
        for(i in 0 until n.childCount){ n.getChild(i)?.let{c->s.append(read(c));c.recycle()} }
        return s.toString()
    }
    override fun onInterrupt() {}
}
