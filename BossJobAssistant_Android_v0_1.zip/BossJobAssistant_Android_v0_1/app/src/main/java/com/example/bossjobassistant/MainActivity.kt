package com.example.bossjobassistant

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,32,32,32) }
        fun field(label:String, value:String): EditText { root.addView(TextView(this).apply{text=label;textSize=16f}); return EditText(this).apply{setText(value); root.addView(this)} }
        root.addView(TextView(this).apply{text="求职助手 · BOSS 半自动版";textSize=24f})
        val keys=field("岗位关键词","工程管理,土木工程,施工员,项目管理,海外工程")
        val salary=field("最低月薪","5000")
        val limit=field("每日最多处理岗位","30")
        val exclude=field("排除关键词","销售,保险,中介,纯电话销售")
        root.addView(Button(this).apply{text="保存设置";setOnClickListener{
            getSharedPreferences("config",0).edit().putString("keywords",keys.text.toString()).putInt("salary",salary.text.toString().toIntOrNull()?:5000).putInt("limit",limit.text.toString().toIntOrNull()?:30).putString("exclude",exclude.text.toString()).apply()
            Toast.makeText(this@MainActivity,"设置已保存",Toast.LENGTH_SHORT).show()
        }})
        root.addView(Button(this).apply{text="① 开启无障碍服务";setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}})
        root.addView(Button(this).apply{text="② 打开 BOSS 直聘";setOnClickListener{
            packageManager.getLaunchIntentForPackage("com.hpbr.bosszhipin")?.let{startActivity(it)} ?: Toast.makeText(this@MainActivity,"请先安装 BOSS 直聘",Toast.LENGTH_LONG).show()
        }})
        root.addView(TextView(this).apply{text="\n半自动模式：助手负责识别符合条件的岗位并提醒；最终投递由你确认。不会尝试绕过验证码或人机验证。"})
        setContentView(root)
    }
}
