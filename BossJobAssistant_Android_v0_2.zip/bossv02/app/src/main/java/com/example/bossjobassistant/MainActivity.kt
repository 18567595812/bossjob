package com.example.bossjobassistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : android.app.Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("config", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
        val title = TextView(this).apply { text = "BOSS求职助手 v0.2\n自动识别并点击“立即沟通”"; textSize = 20f }
        val keywords = EditText(this).apply { hint = "行业关键词（逗号分隔）"; setText(prefs.getString("keywords", DEFAULT_KEYWORDS)) }
        val excludes = EditText(this).apply { hint = "排除关键词（逗号分隔）"; setText(prefs.getString("exclude", "销售,客服,主播,保险,房地产中介")) }
        val max = EditText(this).apply { hint = "每日最多沟通次数"; inputType = 2; setText(prefs.getString("dailyMax", "30")) }
        val save = Button(this).apply { text = "保存设置" }
        val access = Button(this).apply { text = "打开无障碍设置" }
        val note = TextView(this).apply { text = "仅在BOSS直聘内工作；匹配行业后自动寻找“立即沟通/立即打招呼”并点击。不会绕过验证码或登录验证。建议先低额度测试。" }
        save.setOnClickListener { prefs.edit().putString("keywords", keywords.text.toString()).putString("exclude", excludes.text.toString()).putString("dailyMax", max.text.toString()).apply(); Toast.makeText(this,"已保存",Toast.LENGTH_SHORT).show() }
        access.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        listOf(title, keywords, excludes, max, save, access, note).forEach { root.addView(it, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(0,12,0,12) }) }
        setContentView(root)
    }
    companion object { const val DEFAULT_KEYWORDS = "土木,建筑,工程管理,项目管理,施工,施工员,造价,预算,结构,监理,BIM,互联网,计算机,软件,程序员,IT,自动化,电气,电气工程,新能源,光伏,储能,机器人,人工智能,AI,大数据,云计算,智能制造,科技" }
}
