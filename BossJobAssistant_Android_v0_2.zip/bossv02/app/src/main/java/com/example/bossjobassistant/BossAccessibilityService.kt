package com.example.bossjobassistant

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BossAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastClickAt = 0L
    private var lastPageKey = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != "com.hpbr.bosszhipin") return
        val root = rootInActiveWindow ?: return
        val text = readText(root)
        val lower = text.lowercase(Locale.getDefault())
        val prefs = getSharedPreferences("config", MODE_PRIVATE)
        val keywords = (prefs.getString("keywords", MainActivity.DEFAULT_KEYWORDS) ?: "")
            .split(",", "，").map { it.trim().lowercase(Locale.getDefault()) }.filter { it.isNotBlank() }
        val excludes = (prefs.getString("exclude", "销售,客服,主播,保险,房地产中介") ?: "")
            .split(",", "，").map { it.trim().lowercase(Locale.getDefault()) }.filter { it.isNotBlank() }
        val max = (prefs.getString("dailyMax", "30") ?: "30").toIntOrNull()?.coerceIn(1,200) ?: 30
        if (todayCount() >= max) return
        val jobSignals = listOf("职位", "薪资", "经验", "学历", "招聘", "岗位").count { lower.contains(it) }
        if (jobSignals < 2) return
        if (excludes.any { lower.contains(it) }) return
        if (!keywords.any { lower.contains(it) }) return
        val pageKey = lower.hashCode().toString()
        if (pageKey == lastPageKey && System.currentTimeMillis() - lastClickAt < 10000) return
        if (System.currentTimeMillis() - lastClickAt < 1500) return
        val button = findClickableByTexts(root, listOf("立即沟通", "立即打招呼")) ?: return
        lastPageKey = pageKey
        lastClickAt = System.currentTimeMillis()
        handler.postDelayed({
            if (button.isVisibleToUser && button.isEnabled) {
                val ok = button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (ok) incrementToday()
                Toast.makeText(this, if (ok) "已自动点击立即沟通（${todayCount()}/$max）" else "找到沟通按钮但点击失败", Toast.LENGTH_SHORT).show()
            }
        }, 600)
    }

    private fun readText(node: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        node.text?.let { sb.append(it).append(' ') }
        node.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until node.childCount) node.getChild(i)?.let { child -> sb.append(readText(child)); child.recycle() }
        return sb.toString()
    }

    private fun findClickableByTexts(node: AccessibilityNodeInfo, texts: List<String>): AccessibilityNodeInfo? {
        val label = (node.text?.toString() ?: "") + " " + (node.contentDescription?.toString() ?: "")
        if (texts.any { label.contains(it) } && node.isClickable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            val found = findClickableByTexts(child, texts)
            if (found != null) { child.recycle(); return found }
            child.recycle()
        }
        return null
    }

    private fun todayKey() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    private fun todayCount(): Int { val p=getSharedPreferences("daily",MODE_PRIVATE); return if(p.getString("date","")==todayKey()) p.getInt("count",0) else 0 }
    private fun incrementToday() { val p=getSharedPreferences("daily",MODE_PRIVATE); val c=if(p.getString("date","")==todayKey()) p.getInt("count",0) else 0; p.edit().putString("date",todayKey()).putInt("count",c+1).apply() }
    override fun onInterrupt() {}
}
